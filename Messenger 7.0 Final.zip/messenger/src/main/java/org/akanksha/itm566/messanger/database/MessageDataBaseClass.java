package org.akanksha.itm566.messanger.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.akanksha.itm566.messanger.model.Message;

public class MessageDataBaseClass extends ConnectionDao {
	private static Map<Long, Message> messages = new HashMap<>();
	/*public static void main(String args[]){
		//Message message = new Message(99, "test Message updated", "test author");
		//addMessage(message);
		//updateMessage(message);
		//removeMessage(message.getId());
	}*/

	public static Map<Long, Message> getMessages() {
		Connection con;
		try {
			con = new ConnectionDao().getConnection();
			Statement st = (Statement) con.createStatement();
			ResultSet result = st.executeQuery("Select * from message");
			while (result.next()) {
				Long id = result.getLong("id");
				String message = result.getString("message");
				Timestamp created = result.getTimestamp("created");
				String author = result.getString("author");
				messages.put(id, new Message(id, message, author, created));
			}
			con.close();
		} catch (SQLException ex) {
			System.out.println(ex);
		}
		/*
		 * if(messages.size()==0){ messages.put(1L, new Message(1,
		 * "This is my first message", "ProfileName1")); messages.put(2L, new
		 * Message(2, "This is my second message", "ProfileName2")); }
		 */
		return messages;
	}

	public static Message addMessage(Message message) {
		Connection con;
		PreparedStatement ps;
		try {
			con = new ConnectionDao().getConnection();
			ps = con.prepareStatement("insert into message values(?,?,?,?)");
			ps.setLong(1, message.getId());
			ps.setString(2, message.getMessage());
			ps.setTimestamp(3, new Timestamp(new Date().getTime()));
			ps.setString(4, message.getAuthor());
			int i = ps.executeUpdate();
			if (i != 0) {
				System.out.println("Message Inserted");
			} else {
				System.out.println(" Message not Inserted");
			}
			ps.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return message;
	}

	public static Message updateMessage(Message message) {
		Connection con;
		PreparedStatement ps;
		try {
			con = new ConnectionDao().getConnection();
			ps = con.prepareStatement("update test.message set message=?, author =? where id=?");
			ps.setString(1, message.getMessage());
			ps.setString(2, message.getAuthor());
			ps.setLong(3, message.getId());
			int i = ps.executeUpdate();
			if (i != 0) {
				System.out.println("Message updated");
			} else {
				System.out.println("Message not updated");
			}
			ps.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return message;
	}

	public static boolean removeMessage(long messageId) {
		Connection con;
		PreparedStatement ps;
		try {
			con = new ConnectionDao().getConnection();
			ps = con.prepareStatement("delete from test.message where id=?");
			ps.setLong(1, messageId);
			int i = ps.executeUpdate();
			if (i != 0) {
				System.out.println("Message deleted");
			} else {
				System.out.println("Message not delete");
			}
			ps.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
}
