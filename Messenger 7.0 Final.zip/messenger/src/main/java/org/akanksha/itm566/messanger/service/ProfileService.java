package org.akanksha.itm566.messanger.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import org.akanksha.itm566.messanger.database.ProfileDataBaseClass;
import org.akanksha.itm566.messanger.model.Profile;

public class ProfileService {

	private Map<Long, Profile> profiles = ProfileDataBaseClass.getProfiles();
	public ProfileService() {

	}
	
	public List<Profile> getAllProfiles() {
		ArrayList<Profile> sortedArrayList = new ArrayList<Profile>(profiles.values());
		for(Profile profileObj:sortedArrayList){
			profileObj.getLinks().clear();
		}
		Collections.sort(sortedArrayList,new MySalaryComp());
		return sortedArrayList;

	}
	
	public Profile getProfile(String profileName) {
		for(Profile profileObj:profiles.values()){
			if(profileObj.getProfileName().equals(profileName)){
			profiles.get(profileObj.getId());
			return profileObj;
			}
		}
		return null;
	}
	
	public Profile addProfile(Profile profile) {
		profile.setId(profiles.size()+1);
		profiles.put(profile.getId(),profile);
		return profile;

	}
	
	public Profile updateProfile(Profile profile) {
		if (profile.getId()<=0){
			return null;
		}else {
			Profile existingProfile = profiles.get(profile.getId());
			//if existing profile is not found create a new one.
			if(existingProfile==null){
				profile.setId(profiles.size()+1);
				profiles.put(profile.getId(),profile);
			}
			//If profile is found update all its details
			else{
				//update all the needed fields.In our case just update the profile name 
				existingProfile.setProfileName(profile.getProfileName());
				existingProfile.setFirstName(profile.getFirstName());
				existingProfile.setLastName(profile.getLastName());
				profiles.put(existingProfile.getId(),existingProfile);
			}
		}
		
		return profile;
	}
	
	public void removeProfile(String profileName) {
		for(Profile profileObj:profiles.values()){
			if(profileObj.getProfileName().equals(profileName)){
			profiles.remove(profileObj.getId());
			break;
			}
		}
	}
	
	
}
class MySalaryComp implements Comparator<Profile>{
	 
    @Override
    public int compare(Profile p1,Profile p2) {
        if(p1.getId() > p2.getId()){
            return 1;
        } else {
            return -1;
        }
    }
}

