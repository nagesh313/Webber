package org.akanksha.itm566.messanger.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.akanksha.itm566.messanger.model.Comment;

public class CommentDataBaseClass extends ConnectionDao {
	public static void main(String args[]) {
		// Comment comment= new Comment(1,"test Comment","test User");
		// addComments(comment);
		// removeComment(comment.getId());
		// updateComment(comment);
	}

	private static Map<Long, Comment> comments = new HashMap<>();

	public static Map<Long, Comment> getComments() {
		Connection con;
		try {
			con = new ConnectionDao().getConnection();
			Statement st = (Statement) con.createStatement();
			ResultSet result = st.executeQuery("Select * from Comment");
			while (result.next()) {
				Long id = result.getLong("id");
				String comment = result.getString("comment");
				String author = result.getString("author");
				comments.put(id, new Comment(id, comment, author));
			}
			con.close();
		} catch (SQLException ex) {
			System.out.println(ex);
		}
		return comments;
	}

	public static Comment addComments(Comment comment) {
		Connection con;
		PreparedStatement ps;
		try {
			con = new ConnectionDao().getConnection();
			ps = con.prepareStatement("insert into comment values(?,?,?,?)");
			ps.setLong(1, comment.getId());
			ps.setString(2, comment.getComment());
			ps.setString(3, comment.getAuthor());
			ps.setTimestamp(4, new Timestamp(new Date().getTime()));
			int i = ps.executeUpdate();
			if (i != 0) {
				System.out.println("Inserted");
			} else {
				System.out.println("not Inserted");
			}
			ps.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return comment;
	}

	public static Comment updateComment(Comment comment) {
		Connection con;
		PreparedStatement ps;
		try {
			con = new ConnectionDao().getConnection();
			ps = con.prepareStatement("update test.comment set comment=?,author=?,created = now() where id=?");
			ps.setString(1, comment.getComment());
			ps.setString(2, comment.getAuthor());
			ps.setLong(3, comment.getId());
			int i = ps.executeUpdate();
			if (i != 0) {
				System.out.println("updated");
			} else {
				System.out.println("not updated");
			}
			ps.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return comment;
	}

	public static boolean removeComment(long commentId) {
		Connection con;
		PreparedStatement ps;
		try {
			con = new ConnectionDao().getConnection();
			ps = con.prepareStatement("delete from test.comment where id=?");
			ps.setLong(1, commentId);
			int i = ps.executeUpdate();
			if (i != 0) {
				System.out.println("deleted");
			} else {
				System.out.println("not delete");
			}
			ps.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
}
