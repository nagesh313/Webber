/*package org.akanksha.itm566.messanger.database;

import java.util.HashMap;
import java.util.Map;


import org.akanksha.itm566.messanger.model.Message;
import org.akanksha.itm566.messanger.model.Profile;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;

import org.akanksha.itm566.messanger.model.Comment;


public class DatabaseClass extends ConnectionDao{

	private static Map<Long, Message> messages = new HashMap<>();
	private static Map<Long, Profile> profiles = new HashMap<>();
	private static Map<Long,Comment> comments = new HashMap<>();

	
	public static Map<Long, Message> getMessages() {
		Connection con;
		try {
			con = new DatabaseClass().getConnection();
		     Statement st = (Statement) con.createStatement(); 
		    ResultSet result= st.executeQuery("Select * from Message");
		    while (result.next()){
		    	Long id = result.getLong("id");
		    	String message = result.getString("message");
		    	Timestamp created = result.getTimestamp("created");
		    	String author = result.getString("author");
		    	messages.put(id,new Message(id, message, author,created));
		    }
		     st.executeUpdate("INSERT INTO incomeCalc " + "VALUES (3, 75, 6, 25, 18.50)");
		     con.close();
		}
		catch (SQLException ex) {
			System.out.println(ex);
		 } 
		if(messages.size()==0){
			messages.put(1L, new Message(1, "This is my first message", "ProfileName1"));
			messages.put(2L, new Message(2, "This is my second message", "ProfileName2"));
		}
		return messages;
	}
	
	public static Map<Long, Profile> getProfiles() {

		Connection con;
		try {
			con = new DatabaseClass().getConnection();
		     Statement st = (Statement) con.createStatement(); 
		    ResultSet result= st.executeQuery("Select * from profile");
		    while (result.next()){
		    	Long id = result.getLong("id");
		    	String profileName = result.getString("profile_name");
		    	String firstName = result.getString("first_name");
		    	String lastName = result.getString("last_name");
		    	profiles.put(id,new Profile(id, profileName, firstName, lastName));
		    }
		     con.close();
		}
		catch (SQLException ex) {
			System.out.println(ex);
		 } 
		if(profiles.size()==0){
			profiles.put(1L, new Profile(1, "ProfileName1", "Hosea","Lee"));
			profiles.put(2L, new Profile(2, "ProfileName2", "AkanKsha","Patil"));
			profiles.put(3L,  new Profile(3, "ProfileName3", "Patlu","Patil"));
		}
		return profiles;
	}
	
	public static Map<Long, Comment> getComments() {
		Connection con;
		try {
			con = new DatabaseClass().getConnection();
		     Statement st = (Statement) con.createStatement(); 
		    ResultSet result= st.executeQuery("Select * from Comment");
		    while (result.next()){
		    	Long id = result.getLong("id");
		    	String comment = result.getString("comment");
		    	String author = result.getString("author");
		    comments.put(id, new Comment(id, comment, author));
		    }
		     con.close();
		}
		catch (SQLException ex) {
			System.out.println(ex);
		 } 
		if(comments.size()==0){
		comments.put(1L, new Comment(1L, "This is the first comment on first message", "profileName1"));
		comments.put(1L, new Comment(1L, "This is the second comment on first message", "ProfileName2"));
		messages.get(1L).setComments(comments);}		
		return comments;
	}
}*/