/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.akanksha.itm566.messanger.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author crs
 */
public class ConnectionDao {
	public static void main(String args[]){
		new ConnectionDao().getConnection();
	}
    Connection con;
    String url="jdbc:mysql://localhost:3306/test";
    String username="root";
    String password="*123#Target";
   
    private void createConnection() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            System.out.println("Error While Loading Driver");
            ex.printStackTrace();
        }
        try {
        	
            con = DriverManager.getConnection(url, username,password);
            con.setAutoCommit(true);
        } catch (SQLException ex) {
            System.out.println("Error While Creating Connection");
           ex.printStackTrace();
        }
    }

    public Connection getConnection() {
        createConnection();
        return con;
    }
    
    public void closeConnection() {
        try {
            if(!con.isClosed())
            con.close();
        } catch (SQLException ex) {
            System.out.println("Error While Closing Connection");
            ex.printStackTrace();
        }
    }

    @Override
    protected void finalize() throws Throwable {
        super.finalize(); //To change body of generated methods, choose Tools | Templates.
        this.closeConnection();
    }

}
