package org.akanksha.itm566.messanger.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import org.akanksha.itm566.messanger.model.Profile;

public class ProfileDataBaseClass extends ConnectionDao {
	
	/*
	 * public static void main(String args[]) { Profile profile = new
	 * Profile(99, "test profile name", "test profile first name",
	 * "test profile last name "); //addProfile(profile);
	 * //updateProfile(profile); //removeProfile(profile.getId());
	 * 
	 * }
	 */

	private static Map<Long, Profile> profiles = new HashMap<>();

	public static Map<Long, Profile> getProfiles() {

		Connection con;
		try {
			con = new ConnectionDao().getConnection();
			Statement st = (Statement) con.createStatement();
			ResultSet result = st.executeQuery("Select * from profile");
			while (result.next()) {
				Long id = result.getLong("id");
				String profileName = result.getString("profile_name");
				String firstName = result.getString("first_name");
				String lastName = result.getString("last_name");
				profiles.put(id, new Profile(id, profileName, firstName, lastName));
			}
			con.close();
		} catch (SQLException ex) {
			System.out.println(ex);
		}
		/*
		 * if(profiles.size()==0){ profiles.put(1L, new Profile(1,
		 * "ProfileName1", "Hosea","Lee")); profiles.put(2L, new Profile(2,
		 * "ProfileName2", "AkanKsha","Patil")); profiles.put(3L, new Profile(3,
		 * "ProfileName3", "Patlu","Patil")); }
		 */
		return profiles;
	}

	public static Profile addProfile(Profile profile) {
		Connection con;
		PreparedStatement ps;
		try {
			con = new ConnectionDao().getConnection();
			ps = con.prepareStatement("insert into profile values(?,?,?,?,now())");
			ps.setLong(1, profile.getId());
			ps.setString(2, profile.getProfileName());
			ps.setString(3, profile.getFirstName());
			ps.setString(4, profile.getLastName());
			int i = ps.executeUpdate();
			if (i != 0) {
				System.out.println("Profile Inserted");
			} else {
				System.out.println(" Profile not Inserted");
			}
			ps.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return profile;
	}

	public static Profile updateProfile(Profile profile) {
		Connection con;
		PreparedStatement ps;
		try {
			con = new ConnectionDao().getConnection();
			ps = con.prepareStatement("update test.profile set profile_name=?, first_name =?, last_name =? where id=?");
			ps.setString(1, profile.getProfileName());
			ps.setString(2, profile.getFirstName());
			ps.setString(3, profile.getLastName());
			ps.setLong(4, profile.getId());
			int i = ps.executeUpdate();
			if (i != 0) {
				System.out.println("Profile updated");
			} else {
				System.out.println("Profile not updated");
			}
			ps.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return profile;
	}

	public static boolean removeProfile(long profileId) {
		Connection con;
		PreparedStatement ps;
		try {
			con = new ConnectionDao().getConnection();
			ps = con.prepareStatement("delete from test.Profile where id=?");
			ps.setLong(1, profileId);
			int i = ps.executeUpdate();
			if (i != 0) {
				System.out.println("Profile deleted");
			} else {
				System.out.println("Profile not delete");
			}
			ps.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
}
