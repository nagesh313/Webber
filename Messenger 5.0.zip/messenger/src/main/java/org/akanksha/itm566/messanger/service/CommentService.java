package org.akanksha.itm566.messanger.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.akanksha.itm566.messanger.database.DatabaseClass;
import org.akanksha.itm566.messanger.model.Comment;
import org.akanksha.itm566.messanger.model.Message;

public class CommentService {
	
	private Map<Long, Message> messages = DatabaseClass.getMessages();
	public CommentService() {
		messages.put(1L, new Message(1, "This is my first message", "profileName1"));
		messages.put(2L, new Message(2, "This is my second message", "ProfileName2"));
		Map<Long, Comment> commentMap = new HashMap<>();
		commentMap.put(1L, new Comment(1L, "This is the first comment on first message", "profileName1"));
		commentMap.put(1L, new Comment(1L, "This is the second comment on first message", "ProfileName2"));
		messages.get(1L).setComments(commentMap);		
	}
	
	public List<Comment> getAllComments(long messageId) {
		Map<Long, Comment> comments = messages.get(messageId).getComments();
		return new ArrayList<Comment>(comments.values());
	}
	
	public Comment getComment(long messageId, long commentId) {
		
		Map<Long, Comment> comments = messages.get(messageId).getComments();
		Comment comment = comments.get(commentId);
		return comment;
	}
	
	public Comment addComment(long messageId, Comment comment) {
		Map<Long, Comment> comments = messages.get(messageId).getComments();
		comment.setId(comments.size() + 1);
		comments.put(comment.getId(), comment);
		return comment;
	}
	
	public Comment updateComment(long messageId, Comment comment) {
		Map<Long, Comment> comments = messages.get(messageId).getComments();
		if (comment.getId() <= 0) {
			return null;
		}
		comments.put(comment.getId(), comment);
		return comment;
	}
	
	public Comment removeComment(long messageId, long commentId) {
		Map<Long, Comment> comments = messages.get(messageId).getComments();
		return comments.remove(commentId);
	}
		
}