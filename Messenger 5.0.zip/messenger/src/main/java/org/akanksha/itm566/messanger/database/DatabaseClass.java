package org.akanksha.itm566.messanger.database;

import java.util.HashMap;
import java.util.Map;

import javax.xml.stream.events.Comment;

import org.akanksha.itm566.messanger.model.Message;
import org.akanksha.itm566.messanger.model.Profile;
import org.akanksha.itm566.messanger.model.Profile;


public class DatabaseClass extends ConnectionDao{

	private static Map<Long, Message> messages = new HashMap<>();
	private static Map<Long, Profile> profiles = new HashMap<>();
	private static Map<Long,Comment> comments = new HashMap<>();

	
	public static Map<Long, Message> getMessages() {
		return messages;
	}
	
	public static Map<Long, Profile> getProfiles() {
		return profiles;
	}
	
	public static Map<Long, Comment> getComments() {
		return comments;
	}
}